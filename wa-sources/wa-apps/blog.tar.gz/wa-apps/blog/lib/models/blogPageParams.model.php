<?php

class blogPageParamsModel extends waPageParamsModel
{
    protected $table = 'blog_page_params';
}