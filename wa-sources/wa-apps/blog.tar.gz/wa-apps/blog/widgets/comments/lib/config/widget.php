<?php

return array(
    'name' => /*_wp*/('Comments'),
    'size' => array('2x2','1x1','2x1'),
    'img' => 'img/comments.png',
    'version' => '1.1',
    'vendor' => 'webasyst',
);
