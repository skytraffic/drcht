<?php

return array(
    'name' => /*_wp*/('Posts'),
    'size' => array('2x2', '2x1', '1x1'),
    'img' => 'img/posts.png',
    'version' => '1.1',
    'vendor' => 'webasyst',
);
