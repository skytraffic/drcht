<?php

class waApiAuthCodesModel extends waModel
{
    protected $id = 'code';
    protected $table = 'wa_api_auth_codes';
}