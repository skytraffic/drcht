<?php

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'analytics' => true,
    'version' => '1.5.3',
    'critical'=>'1.5.0',
    'vendor' => 'webasyst',
);
